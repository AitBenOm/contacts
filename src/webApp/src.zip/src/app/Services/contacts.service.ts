import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Contact} from "../new-contact/contact";

@Injectable()
export class ContactsService {

  constructor(private http:HttpClient) { }
  getContacts(){
    return this.http.get("http://localhost:8080/chercherContacts?mc=&size=5&page=0");
  }
  // getContactsParMotCle(motCle:string){
  //      return this.http.get("http://localhost:8080/chercherContacts?mc="+motCle+"&size=5&page=0");
  // }

  getContactsParMotCle(size: number, motCle: string, page: number){
       return this.http.get("http://localhost:8080/chercherContacts?mc="+motCle+"&size="+size+"&page="+page);
  }

  saveContact(contact: Contact){
    console.log(contact);
    return this.http.post("http://localhost:8080/contacts", contact);
  }

}
