import { Component, OnInit } from '@angular/core';
import {Contact} from "./contact";
import {ContactsService} from "../Services/contacts.service";
import {Subject} from "rxjs/Subject";
import {Router} from "@angular/router";

@Component({
  selector: 'app-new-contact',
  templateUrl: './new-contact.component.html',
  styleUrls: ['./new-contact.component.css']
})
export class NewContactComponent implements OnInit {
contact: Contact= new Contact();
mode: number=1;

  constructor(private contactService: ContactsService, private router: Router) { }

  ngOnInit() {
  }
  enregistrer(){
    console.log(this.contact.prenom);
    this.contactService.saveContact(this.contact).subscribe(
      (data)=>{
        // this.router.navigate(['/contacts']);
       this.mode=2;
      },error =>{
        console.log(error);
      }
    );

  }

}
