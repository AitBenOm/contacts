export class Contact {
   public nom: string;
   public prenom: string;
   public email: string;
   public dateNaissance: Date;
   public tel: string;
   public photo: string;


}
