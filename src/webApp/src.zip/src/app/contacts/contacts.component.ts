import { Component, OnInit } from '@angular/core';

import "rxjs/add/operator/map"

import {ContactsService} from "../Services/contacts.service";

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css']
})
export class ContactsComponent implements OnInit {

  pageContact:any;
  currentPage: number=0;
  size: number=5;
  motCle: string='';
  pages:Array<number>;
  constructor(private contactService : ContactsService) { }

  ngOnInit() {

    this.contactService.getContacts()
      .subscribe(data =>{
  this.pageContact=data;
       this.pages= new Array(data.totalPages);
  console.log (data);
    },
      error=>{
        console.log(error);
      })
  }

  chercher(){
this.contactService.getContactsParMotCle(this.size,this.motCle, this.currentPage)
  .subscribe(data =>{
      this.pageContact=data;
      this.pages= new Array(data.totalPages);
      console.log (this.currentPage);
    },
    error=>{
      console.log(error);
    })
  }
  getPage(page: number) {
    this.currentPage = page;
    this.chercher();
  }

}
