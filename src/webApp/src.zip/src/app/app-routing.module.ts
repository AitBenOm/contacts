import { NgModule } from '@angular/core';
import {Routes, RouterModule, PreloadAllModules} from '@angular/router';
import {ContactsComponent} from "./contacts/contacts.component";
import {AboutComponent} from "./about/about.component";
import {NewContactComponent} from "./new-contact/new-contact.component";



const appRoutes: Routes = [
 // { path: '', redirectTo: '/recipes', pathMatch: 'full' },
  //{ path: 'recipes', loadChildren: './recipes/recipes.module.ts#RecipesModule'},
  {path: '', redirectTo: '/about', pathMatch: 'full' },
  {path: 'contacts', component: ContactsComponent},
  {path: 'about', component: AboutComponent},
  {path: 'new-contact', component: NewContactComponent},

  // { path: 'login', component: LoginComponent },
  // { path: 'register', component: RegisterComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes, {preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
